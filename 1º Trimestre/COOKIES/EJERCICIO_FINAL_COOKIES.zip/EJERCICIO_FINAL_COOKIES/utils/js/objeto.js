class objeto{
    nombre;
    apellido;
    telefono;
    disponibilidad;

    constructor(nombre,apellido,telefono,disponibilidad){
        this.nombre = nombre;
        this.apellido = apellido;
        this.telefono = telefono;
        this.disponibilidad = disponibilidad;
    }
}